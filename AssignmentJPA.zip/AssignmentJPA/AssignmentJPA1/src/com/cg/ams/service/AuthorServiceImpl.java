package com.cg.ams.service;

import com.cg.ams.dao.AuthorDAO;
import com.cg.ams.dao.AuthorDAOImpl;
import com.cg.ams.entities.Author;

public class AuthorServiceImpl implements AuthorService {

	AuthorDAO adao = new AuthorDAOImpl();
	
	public AuthorServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void insertAuthor(Author author) {
		
		adao.insertAuthor(author);
	}

	@Override
	public void removeAuthor(Author author) {
		
		adao.removeAuthor(author);
	}

	@Override
	public void updateAuthor(Author author) {
		
		adao.updateAuthor(author);
	}

	@Override
	public Author findAuthor(int aid) {
		
		return adao.findAuthor(aid);
	}

}
