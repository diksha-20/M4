package com.cg.webservices.ws;

public interface ProductWS {
	
}
