package com.cg.labtwo.dao;

import java.util.List;

import com.cg.labtwo.entities.Author;
import com.cg.labtwo.entities.Book;



public interface ClientDao {

	public void commitTransaction();
	public  void beginTransaction();
	public  void addAuthor(Author author);
	public  void addBook(Book book);
	public List<Book> getAllBooks() ;
	public List<Book> getBooksInPriceRange(double low,double high);
	public List<Author> getAuthorName(int id);
	public List<Book> getBookDetail(String name);
}
