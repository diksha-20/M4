package com.cg.ams.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.ams.entities.Author;

public class AuthorDAOImpl implements AuthorDAO {

	EntityManager em;
	
	public AuthorDAOImpl() {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		em = emf.createEntityManager();
	}

	@Override
	public void insertAuthor(Author author) {
		em.getTransaction().begin();
		em.persist(author);
		em.getTransaction().commit();

	}

	@Override
	public void removeAuthor(Author author) {
		em.getTransaction().begin();
		em.remove(author);
		em.getTransaction().commit();

	}

	@Override
	public void updateAuthor(Author author) {
		em.getTransaction().begin();
		em.persist(author);
		em.getTransaction().commit();


	}

	@Override
	public Author findAuthor(int authorId) {
		
		return em.find(Author.class, authorId);

	}

}
