package com.cg.labtwo.dao;

import java.util.List;

import javax.persistence.EntityManager;



import javax.persistence.Query;

import com.cg.labtwo.entities.Author;
import com.cg.labtwo.entities.Book;

public class ClientDaoImpl implements ClientDao {
	private EntityManager entityManager;
	public ClientDaoImpl() {
		// TODO Auto-generated constructor stub
		entityManager=ClientUtil.getEntityManager();
	}
	@Override
	public void commitTransaction() {
		// TODO Auto-generated method stub
		entityManager.getTransaction().commit();
		entityManager.close();
	}

	@Override
	public void beginTransaction() {
		// TODO Auto-generated method stub
		//entityManager.getTransaction().begin();
	}

	@Override
	public void addAuthor(Author author) {
		// TODO Auto-generated method stub
		entityManager.persist(author);
	}

	@Override
	public void addBook(Book book) {
		// TODO Auto-generated method stub
		entityManager.persist(book);
		
	}
	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		Query query=entityManager.createQuery("from Book");
		//query.setParameter("userid",500);
		@SuppressWarnings("unchecked")
		List<Book> bookList=query.getResultList();
		return bookList;
	}
	@Override
	public List<Book> getBooksInPriceRange(double low, double high) {
		// TODO Auto-generated method stub
		Query query=entityManager.createQuery("from Book where price between :low and :high");
		query.setParameter("low",low);
		query.setParameter("high",high);
		List<Book> bookList=query.getResultList();
		return bookList;
	}
	public List<Book> getBookDetail(String name){
		Query query=entityManager.createQuery("SELECT b FROM Book b join b.author a WHERE a.name=:name");
		query.setParameter("name",name);
		return query.getResultList();
		
	}
	//GET AUTHOR NAME
	public List<Author> getAuthorName(int id){
		Query query=entityManager.createQuery("SELECT a FROM Author a join a.List b WHERE b.isBn=:id");
		query.setParameter("id",id);
		return query.getResultList();
		
	}

}
