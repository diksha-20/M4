package com.capgemini.trainee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.trainee.bean.Trainee;
import com.capgemini.trainee.dao.ITraineeDao;

@Service
public class TraineeService implements ITraineeService {

	@Autowired
	ITraineeDao traineeDao;
	
	@Override
	public Trainee addTrainee(Trainee trainee) {
		return traineeDao.addTrainee(trainee);
	}

	@Override
	public void deleteTrainee(String trainee) {
		// TODO Auto-generated method stub
		traineeDao.deleteTrainee(trainee);
	}

	@Override
	public Trainee modifyTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return traineeDao.modifyTrainee(trainee);
	}

	@Override
	public Trainee retrieveTraineeDetails(int traineeId) {
		// TODO Auto-generated method stub
		return traineeDao.retrieveTraineeDetails(traineeId);
	}

	@Override
	public List<Trainee> getAllTraineesDetails() {
		// TODO Auto-generated method stub
		return traineeDao.getAllTraineesDetails();
	}

}
