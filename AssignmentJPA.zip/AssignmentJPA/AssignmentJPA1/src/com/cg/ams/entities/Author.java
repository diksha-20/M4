package com.cg.ams.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="Author")

@NamedQueries(
		@NamedQuery(name="fetchAll",query="SELECT a FROM Author a")
		)

public class Author {

	@Id
	@Column(name="authorId")
	private int aId;
	private String firstName;
	private String lastName;
	private String middleName;
	private String phoneNo;
	public Author() {
		super();
	}
	public Author(int authorId, String firstName, String lastName,
			String middleName, String phoneNo) {
		super();
		this.aId = authorId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.middleName = middleName;
		this.phoneNo = phoneNo;
	}
	public int getAuthorId() {
		return aId;
	}
	public void setAuthorId(int authorId) {
		this.aId = authorId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	@Override
	public String toString() {
		return "Author [authorId=" + aId + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", middleName=" + middleName
				+ ", phoneNo=" + phoneNo + "]";
	}

}
