package com.cg.assignment.one.service;

import java.util.ArrayList;

public interface IEmployeeService {

	public ArrayList<String> getDataList();
}
