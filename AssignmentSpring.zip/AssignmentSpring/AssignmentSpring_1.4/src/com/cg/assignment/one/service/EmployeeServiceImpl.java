package com.cg.assignment.one.service;

import java.util.ArrayList;

import com.cg.assignment.one.dao.EmployeeDaoImpl;
import com.cg.assignment.one.dao.IEmployeeDAO;

public class EmployeeServiceImpl implements IEmployeeService {

	IEmployeeDAO employeeDao;
	
	public EmployeeServiceImpl() {
	
	employeeDao=new EmployeeDaoImpl();
	
	}

	@Override
	public ArrayList<String> getDataList() {
		// TODO Auto-generated method stub
		return employeeDao.getDataList();
	}

}
