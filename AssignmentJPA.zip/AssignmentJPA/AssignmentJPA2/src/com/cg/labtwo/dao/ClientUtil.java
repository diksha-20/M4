package com.cg.labtwo.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class ClientUtil {
	
	
	public static EntityManager getEntityManager() {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("LabAssignmentOk");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		return em;
		
		}
		
	}
