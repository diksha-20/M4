package com.cg.assignment.one.dao;

import java.util.ArrayList;

public class EmployeeDaoImpl implements IEmployeeDAO {
	private ArrayList<String> dataList;
	@Override
	public ArrayList<String> getDataList() {
		// TODO Auto-generated method stub
		return dataList;
	}

	public void setDataList(ArrayList<String> dataList) {
		this.dataList = dataList;
	}
	
}
