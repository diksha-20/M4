package com.cg.ams.dao;

import com.cg.ams.entities.Author;

public interface AuthorDAO {

	void insertAuthor(Author author);
	
	void removeAuthor(Author author);
	
	void updateAuthor(Author author);
	
	Author findAuthor(int aid);
}
