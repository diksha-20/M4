package com.cg.labtwo.service;

import java.util.List;

import com.cg.labtwo.entities.Author;
import com.cg.labtwo.entities.Book;



public interface ClientService {
	
	public void addBook(Book book);
	public void addAuthor(Author author);
	public void commit();
	public List<Book> getAllBooks() ;
	public List<Book> getBooksInPriceRange(double low,double high);
    public List<Author> getAuthorName(int id);
    public List<Book> getBookDetail(String name);
}
