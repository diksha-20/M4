package com.cg.ams.pl;

import java.util.Scanner;

import com.cg.ams.entities.Author;
import com.cg.ams.service.AuthorService;
import com.cg.ams.service.AuthorServiceImpl;

public class AuthorClient {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		AuthorService aser = new AuthorServiceImpl();
		
		do{
			System.out.println("1.Add Author");
			System.out.println("2.Find Author");
			System.out.println("3.Update Author");
			System.out.println("4.Remove Author");
			System.out.println("5.Exit");
			System.out.println("Enter your choice");
			
			int choice = sc.nextInt();
			switch(choice){
			
			case 1 : 
				System.out.println("Enter Authors ID : ");
				int aId = sc.nextInt();
				System.out.println("Enter Authors First Name : ");
				String fname = sc.next();
				System.out.println("Enter Authors Middle Name : ");
				String mname = sc.next();
				System.out.println("Enter Authors Last Name : ");
				String lname = sc.next();
				System.out.println("Enter Phone Number : ");
				String phn = sc.next();
			
				Author a = new Author();
				
				a.setAuthorId(aId);
				a.setFirstName(fname);
				a.setMiddleName(mname);
				a.setLastName(lname);
				a.setPhoneNo(phn);
				
				aser.insertAuthor(a);
				
				System.out.println("Author added Successfully....");
				break;
			case 2 : 
				System.out.println("Enter Author id to search : ");
				 aId = sc.nextInt();
				Author a1 = aser.findAuthor(aId);
				System.out.println(a1.getAuthorId()+"\t"+a1.getFirstName()+" "+a1.getMiddleName()+" "+a1.getLastName()+"\t"+a1.getPhoneNo());
				break;
			case 3 : 
				System.out.println("Enter Author Id to modify : ");
				aId = sc.nextInt();
				Author a2 = aser.findAuthor(aId);
				System.out.println(a2.getAuthorId()+"\t"+a2.getFirstName()+" "+a2.getMiddleName()+" "+a2.getLastName()+"\t"+a2.getPhoneNo());
				System.out.println("Enter the new phone no : ");
				phn = sc.next();
				a2.setPhoneNo(phn);
				aser.updateAuthor(a2);
				System.out.println("Author Modified");
				break;
			case 4 : 
				System.out.println("Enter Author id to remove : ");
				aId = sc.nextInt();
				 a2 = aser.findAuthor(aId);
				 System.out.println(a2.getAuthorId()+a2.getFirstName()+a2.getMiddleName()+a2.getLastName()+a2.getPhoneNo());
				 System.out.println("Do you want to delete : (y/n)");
				 char ch = sc.next().charAt(0); 
				 if( ch=='y' || ch=='Y') {
					 aser.removeAuthor(a2);
						System.out.println("Author Removed...");
				 }
				break;
			
			}
			
		}while(true);
	}

}
