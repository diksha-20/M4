package com.cg.assignment.one.dao;

import java.util.ArrayList;

public interface IEmployeeDAO {

	public ArrayList<String> getDataList();


}
