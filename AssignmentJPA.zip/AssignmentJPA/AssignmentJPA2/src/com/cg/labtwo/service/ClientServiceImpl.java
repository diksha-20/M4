package com.cg.labtwo.service;


import java.util.List;

import com.cg.labtwo.dao.ClientDao;
import com.cg.labtwo.dao.ClientDaoImpl;
import com.cg.labtwo.entities.Author;
import com.cg.labtwo.entities.Book;

public class ClientServiceImpl implements ClientService {

	private ClientDao dao;
	public ClientServiceImpl() {
		// TODO Auto-generated constructor stub
		dao=new ClientDaoImpl();
	}
	

	@Override
	public void addBook(Book book) {
		// TODO Auto-generated method stub
		//dao.beginTransaction();
		dao.addBook(book);
		//dao.commitTransaction();
	}


	@Override
	public void addAuthor(Author author) {
		// TODO Auto-generated method stub
		//dao.beginTransaction();
		dao.addAuthor(author);
		//dao.commitTransaction();
		
	}


	@Override
	public void commit() {
		// TODO Auto-generated method stub
		dao.commitTransaction();
	}


	@Override
	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return dao.getAllBooks();
	}


	@Override
	public List<Book> getBooksInPriceRange(double low, double high) {
		// TODO Auto-generated method stub
		return dao.getBooksInPriceRange(low, high);
	}


	@Override
	public List<Author> getAuthorName(int id) {
		// TODO Auto-generated method stub
		return dao.getAuthorName(id);
	}


	@Override
	public List<Book> getBookDetail(String name) {
		// TODO Auto-generated method stub
		return dao.getBookDetail(name);
	}

}
