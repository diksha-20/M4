package com.cg.labtwo.entities;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="Book_Details")
public class Book {
	@Id
	
	private int isBn;
	private String title;
	private double price;
	@ManyToMany
	
	Collection<Author> author=new ArrayList<Author>();
	
	public Collection<Author> getAuthor() {
		return author;
	}
	public void setAuthor(Collection<Author> author) {
		this.author = author;
	}
	public int getIsBn() {
		return isBn;
	}
	public void setIsBn(int isBn) {
		this.isBn = isBn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
	

}
