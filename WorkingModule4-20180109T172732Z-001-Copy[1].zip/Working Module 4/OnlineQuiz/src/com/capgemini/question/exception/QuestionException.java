package com.capgemini.question.exception;

public class QuestionException extends Exception {
	private static final long serialVersionUID = -5144675967291648886L;

	public QuestionException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public QuestionException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
