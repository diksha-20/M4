package com.cg.labtwo.pl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.labtwo.entities.Author;
import com.cg.labtwo.entities.Book;
import com.cg.labtwo.service.ClientService;
import com.cg.labtwo.service.ClientServiceImpl;

public class MyUi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClientService service = new ClientServiceImpl();
		Author author=new Author();
		author.setId(100);
		author.setName("ABCD");
		Author authorOne=new Author();
		authorOne.setId(200);
		authorOne.setName("BCD");
        Book book =new Book();
        book.setIsBn(10001);
		book.setTitle("Adv Angular Java");
		book.setPrice(200);
		Book bookOne =new Book();
		bookOne.setIsBn(10002);
		bookOne.setTitle("Adv Angular JS");
		bookOne.setPrice(876);
		
		Book bookTwo =new Book();
		bookTwo.setIsBn(1003);
		bookTwo.setTitle("Backbone JS");
		bookTwo.setPrice(706);
		
		
		author.getList().add(book);
		author.getList().add(bookOne);
		
		authorOne.getList().add(bookOne);
		authorOne.getList().add(bookTwo);
		//book.getAuthor().add(author);
		book.getAuthor().add(author);
		
		bookOne.getAuthor().add(authorOne);
		bookTwo.getAuthor().add(authorOne);
		
		service.addBook(book);
		service.addBook(bookOne);
		service.addBook(bookTwo);
		service.addAuthor(author);
		service.addAuthor(authorOne);
		
		System.out.println("Added Book & Author");
		List<Book> bookList=	service.getAllBooks();
		List<Book> bookPrice=service.getBooksInPriceRange(200,500);
		List<Author> au=service.getAuthorName(10002);
		List<Book> bookData=service.getBookDetail("BCD");
		service.commit();
		
	System.out.println("Book List ..........");
	for (Book book2 : bookList) {
		System.out.println("Book IsBn is "+ book2.getIsBn());
		System.out.println("Book Title is "+ book2.getTitle());
		System.out.println("Book Price is "+ book2.getPrice());
		//System.out.println(book2.getAuthor().size());
	}
		
	System.out.println("Book Price 200 -500 ..........");
	for (Book bookp : bookPrice) {
		System.out.println("Book IsBn is "+ bookp.getIsBn());
		System.out.println("Book Title is "+ bookp.getTitle());
		System.out.println("Book Price is "+ bookp.getPrice());
	}	
		System.out.println("Author Name for Given Book ID");
		for (Author author2 : au) {
			System.out.println(author2.getName());
		}
		
		System.out.println("Book Details of Given Author Name");
		for (Book book2 : bookData) {
			System.out.println(book2.getIsBn());
			System.out.println(book2.getPrice());
			System.out.println(book2.getTitle());
		}
		
		//service.addAuthor(author);
		//service.addAuthor(author);
	    //service.addBook(book);
		//service.addBook(bookOne);
		
		
		
	}

}
