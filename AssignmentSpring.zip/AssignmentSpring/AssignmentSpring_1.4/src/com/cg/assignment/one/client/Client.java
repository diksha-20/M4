package com.cg.assignment.one.client;

import java.util.List;


import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.assignment.one.dao.IEmployeeDAO;
import com.cg.assignment.one.service.EmployeeServiceImpl;
import com.cg.assignment.one.service.IEmployeeService;


public class Client {

	IEmployeeService eser=new EmployeeServiceImpl();
	
	public static void main(String[] args) {
		

		Resource res = new ClassPathResource("beans.xml");
		BeanFactory factory = new XmlBeanFactory(res);
		IEmployeeDAO curr = (IEmployeeDAO)factory.getBean("emp4");
		List curs = curr.getDataList();
		System.out.println(curs);	
		
		
		
	}
	
	
	
}
