package com.cg.ams.service;

import com.cg.ams.entities.Author;

public interface AuthorService {

void insertAuthor(Author author);
	
	void removeAuthor(Author author);
	
	void updateAuthor(Author author);
	
	Author findAuthor(int aid);
}
