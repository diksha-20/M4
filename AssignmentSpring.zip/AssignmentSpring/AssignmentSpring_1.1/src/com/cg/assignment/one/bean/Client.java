package com.cg.assignment.one.bean;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class Client {

	
	public static void main(String[] args) {
		
		BeanFactory container=new XmlBeanFactory(
				new ClassPathResource("spring.xml")
				);
		
		
		Employee employee=(Employee)container.getBean("emp");
		
		
		System.out.println("Employee Details");
		System.out.println("___________________");
		System.out.println("Employee Id: "+employee.getEmployeeId());
		System.out.println("Employee Name: "+employee.getEmployeeName());
		System.out.println("Employee Salary: "+employee.getSalary());
		System.out.println("Employee BU: "+employee.getBusinessunit());
		System.out.println("Employee Age: "+employee.getAge());
	}
	
	
}
